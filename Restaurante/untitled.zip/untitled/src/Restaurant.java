import java.util.ArrayList;

public class Restaurant {
    ArrayList<Dish> dishList;

    public void newOrder(Client client){
        Order order = new Order(client);
    }

    public void loadDish(){

    }
    public static void main(String[] args) {
        while(true){
            System.out.println("1. Fazer pedido \n 2. Sair");

        }
    }
}
